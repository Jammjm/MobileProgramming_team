package com.example.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.ui.databinding.ActivityPetBinding
import com.example.ui.databinding.ActivityVinlyBinding

class vinly : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vinly)

        val binding = ActivityVinlyBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}