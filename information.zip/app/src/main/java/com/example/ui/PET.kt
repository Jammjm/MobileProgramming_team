package com.example.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.ui.databinding.ActivityPaperBinding
import com.example.ui.databinding.ActivityPetBinding

class PET : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pet)

        val binding = ActivityPetBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}