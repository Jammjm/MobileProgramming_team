package com.example.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.ui.databinding.ActivityMainBinding
import com.example.ui.databinding.ActivityStyrofoamBinding

class Styrofoam : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_styrofoam)

        val binding = ActivityStyrofoamBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}