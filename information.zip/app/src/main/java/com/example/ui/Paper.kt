package com.example.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.ui.databinding.ActivityMainBinding
import com.example.ui.databinding.ActivityPaperBinding

class Paper : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_paper)

        val binding = ActivityPaperBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}