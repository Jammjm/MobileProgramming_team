package com.example.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.ui.databinding.ActivityGlassbottleBinding
import com.example.ui.databinding.ActivityMainBinding

class glassbottle : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_glassbottle)


        val binding = ActivityGlassbottleBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}