package com.example.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.ui.databinding.ActivityMainBinding
import com.example.ui.databinding.ActivityMetalcanBinding

class Metalcan : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_metalcan)

        val binding = ActivityMetalcanBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}