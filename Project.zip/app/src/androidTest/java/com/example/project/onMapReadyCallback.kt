package com.example.project

interface onMapReadyCallback {

}
